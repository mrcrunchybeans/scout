import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

class ScannerSheet extends StatefulWidget {
  final String title;
  const ScannerSheet({super.key, this.title = 'Scan a barcode'});

  @override
  State<ScannerSheet> createState() => _ScannerSheetState();
}

class _ScannerSheetState extends State<ScannerSheet> {
  final controller = MobileScannerController(
    detectionSpeed: DetectionSpeed.noDuplicates,
    facing: CameraFacing.back,
    torchEnabled: false,
  );
  bool _handled = false;

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  void _onDetect(BarcodeCapture cap) {
    if (_handled) return;
    if (cap.barcodes.isEmpty) return;

    final raw = cap.barcodes.first.rawValue?.trim();
    if (raw == null || raw.isEmpty) return;

    _handled = true; // prevent multiple pops on fast re-detects
    if (mounted) Navigator.of(context).pop(raw);
  }

  Future<void> _typeManually() async {
    final code = await showDialog<String>(
      context: context,
      builder: (_) {
        final c = TextEditingController();
        return AlertDialog(
          title: const Text('Enter code'),
          content: TextField(
            controller: c,
            decoration: const InputDecoration(
              labelText: 'Barcode or SCOUT lot QR text',
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, c.text.trim()),
              child: const Text('Use'),
            ),
          ],
        );
      },
    );

    if (code != null && code.isNotEmpty && mounted) {
      Navigator.of(context).pop(code);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Text(widget.title, style: theme.textTheme.titleLarge),
                  const Spacer(),
                  IconButton(
                    tooltip: 'Flip camera',
                    icon: const Icon(Icons.cameraswitch),
                    onPressed: () => controller.switchCamera(),
                  ),
                  IconButton(
                    tooltip: 'Toggle torch',
                    icon: const Icon(Icons.flashlight_on),
                    onPressed: () => controller.toggleTorch(),
                  ),
                ],
              ),
              const SizedBox(height: 12),

              // Square preview (works well on phones in web)
              AspectRatio(
                aspectRatio: 1,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      MobileScanner(
                        controller: controller,
                        onDetect: _onDetect,
                      ),
                      // Simple overlay for UX
                      IgnorePointer(
                        ignoring: true,
                        child: Container(
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: Colors.white.withValues(alpha:0.7),
                              width: 2,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 12),
              Text(
                'Point your camera at a barcode.\nNo camera? Enter code manually.',
                textAlign: TextAlign.center,
                style: theme.textTheme.bodySmall,
              ),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                icon: const Icon(Icons.keyboard),
                label: const Text('Enter code manually'),
                onPressed: _typeManually,
              ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }
}
