class SoundFeedback {
  static void ok({num freq = 920, num ms = 110, num volume = .05}) {}
  static void error({num freq = 220, num ms = 180, num volume = .06}) {}
}
