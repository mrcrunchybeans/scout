import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// ---------------------------
/// Brand palette (tweak here)
/// ---------------------------
class BrandColors {
  // Teal brand
  static const primary = Color(0xFF16B3A4);   // lively teal
  static const primaryDark = Color(0xFF0D7E75);
  static const primaryContainer = Color.fromARGB(255, 165, 255, 243);

  // Deep text / navigation (teal-charcoal vibe)
  static const ink = Color(0xFF0F2E2C);       // headings / strong text
  static const inkMuted = Color(0xFF3D5150);  // body

  // Slate accent & subtle outlines
  static const slate = Color(0xFF3B5B59);
  static const outline = Color(0xFFE0ECEA);

  // Backgrounds
  static const bg = Color(0xFFF6FBFA);       // app background
  static const surface = Colors.white;        // cards, sheets
}

/// Helper: subtle drop shadow for cards
const _softShadow = [
  BoxShadow(
    color: Color(0x1A000000), // 10% black
    blurRadius: 12,
    offset: Offset(0, 3),
  ),
];

class AppTheme {
  static ThemeData light() {
    // Base color scheme from seed, then override key surfaces
    final scheme = ColorScheme.fromSeed(
      seedColor: const Color.fromARGB(86, 22, 179, 163),
      brightness: Brightness.light,
    ).copyWith(
      primary: BrandColors.primary,
      onPrimary: Colors.white,
      primaryContainer: BrandColors.primaryContainer,
      onPrimaryContainer: BrandColors.ink,
      surface: BrandColors.surface,
      onSurface: BrandColors.ink,
      secondary: BrandColors.slate,
      onSecondary: Colors.white,
      outline: BrandColors.outline,
    );

    final text = GoogleFonts.interTextTheme().apply(
      bodyColor: BrandColors.inkMuted,
      displayColor: BrandColors.ink,
    );

    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: BrandColors.bg,
      // Typography – slightly larger, confident headings
      textTheme: text.copyWith(
        headlineSmall: text.headlineSmall?.copyWith(
          fontWeight: FontWeight.w800,
          color: BrandColors.ink,
        ),
        titleLarge: text.titleLarge?.copyWith(
          fontWeight: FontWeight.w700,
          color: BrandColors.ink,
        ),
        titleMedium: text.titleMedium?.copyWith(
          fontWeight: FontWeight.w600,
          color: BrandColors.ink,
        ),
        bodyLarge: text.bodyLarge?.copyWith(height: 1.25),
        bodyMedium: text.bodyMedium?.copyWith(height: 1.25),
      ),

      // AppBar – light, minimal, subtle divider
      appBarTheme: AppBarTheme(
        backgroundColor: BrandColors.surface,
        foregroundColor: BrandColors.ink,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        titleTextStyle: GoogleFonts.inter(
          fontSize: 18,
          fontWeight: FontWeight.w700,
          color: BrandColors.ink,
        ),
        toolbarHeight: 64,
      ),

      // Cards – soft shadow, generous radius
      cardTheme: CardThemeData(
        color: const Color(0xFF16B3A4),
        elevation: 0,
        margin: const EdgeInsets.all(0),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        shadowColor: Colors.transparent,
      ),

      // Dividers / outlines – airy, neutral
      dividerTheme: const DividerThemeData(
        thickness: 1,
        space: 1,
        color: BrandColors.outline,
      ),

      // Inputs – pill-ish, filled, subtle outline on focus
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: const Color(0xFFF0F7F6),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: BrandColors.primary, width: 1),
        ),
  labelStyle: TextStyle(color: scheme.onSurface.withValues(alpha: 0.7)),
  hintStyle: TextStyle(color: scheme.onSurface.withValues(alpha: 0.5)),
      ),

      // Chips – soft pills
      chipTheme: ChipThemeData(
        shape: const StadiumBorder(),
        side: BorderSide.none,
        labelStyle: TextStyle(color: BrandColors.ink),
        backgroundColor: const Color(0xFFEAF3F2),
        selectedColor: scheme.primaryContainer,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      ),

      // Segmented buttons – rounder & comfy
      segmentedButtonTheme: SegmentedButtonThemeData(
        style: ButtonStyle(
          shape: WidgetStatePropertyAll(
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          padding: const WidgetStatePropertyAll(EdgeInsets.symmetric(horizontal: 12, vertical: 10)),
        ),
      ),

      // Buttons – friendly radius, bold labels
      filledButtonTheme: FilledButtonThemeData(
        style: ButtonStyle(
          backgroundColor: WidgetStatePropertyAll(BrandColors.primary),
          foregroundColor: const WidgetStatePropertyAll(Colors.white),
          shape: WidgetStatePropertyAll(
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
          padding: const WidgetStatePropertyAll(
            EdgeInsets.symmetric(horizontal: 18, vertical: 12),
          ),
          textStyle: WidgetStatePropertyAll(
            GoogleFonts.inter(fontWeight: FontWeight.w700),
          ),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: ButtonStyle(
          side: WidgetStatePropertyAll(BorderSide(color: BrandColors.primaryDark)),
          foregroundColor: const WidgetStatePropertyAll(BrandColors.primaryDark),
          shape: WidgetStatePropertyAll(
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
          padding: const WidgetStatePropertyAll(
            EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          ),
          textStyle: WidgetStatePropertyAll(
            GoogleFonts.inter(fontWeight: FontWeight.w600),
          ),
        ),
      ),

      // ListTiles – tighter leading/trailing, comfy padding
      listTileTheme: const ListTileThemeData(
        contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        iconColor: BrandColors.slate,
      ),

      // SnackBars – floating, rounded
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: BrandColors.ink,
        contentTextStyle: GoogleFonts.inter(color: Colors.white),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),

      // Elevated surfaces: apply gentle shadows via Material widget usage
      extensions: <ThemeExtension<dynamic>>[
        _CardShadow(shadow: _softShadow),
      ],
    );
  }

  static ThemeData dark() {
    final scheme = ColorScheme.fromSeed(
      seedColor: const Color.fromARGB(91, 22, 179, 163),
      brightness: Brightness.dark,
    ).copyWith(
      primary: const Color.fromARGB(85, 22, 179, 163),
      surface: const Color.fromARGB(255, 0, 0, 0),
      onSurface: Colors.white,
      outline: const Color(0xFF243231),
    );

    final text = GoogleFonts.interTextTheme(ThemeData.dark().textTheme);

    return light().copyWith(
      colorScheme: scheme,
      scaffoldBackgroundColor: scheme.surface,
      textTheme: text,
      cardTheme: light().cardTheme.copyWith(color: scheme.surface),
      snackBarTheme: light().snackBarTheme.copyWith(backgroundColor: scheme.surface),
    );
  }
}

/// Tiny theme extension to opt into shadows on Card wrappers when desired.
class _CardShadow extends ThemeExtension<_CardShadow> {
  final List<BoxShadow> shadow;
  const _CardShadow({required this.shadow});

  @override
  _CardShadow copyWith({List<BoxShadow>? shadow}) =>
      _CardShadow(shadow: shadow ?? this.shadow);

  @override
  _CardShadow lerp(ThemeExtension<_CardShadow>? other, double t) => this;
}
