
// Web implementation using js interop

export 'sound_feedback_stub.dart'
  if (dart.library.html) 'sound_feedback_web.dart';
